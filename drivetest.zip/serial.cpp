// Serial.cpp
// Serial - UART communication functionality
//
//
// rev 1.0 - 2016.04.20
//    - initial version
//
// boredman@boredomprojects.net

#include "serial.h"



Serial::Serial()
{
    fd = -1;    // invalid file descriptor
}


Serial::~Serial()
{
    close(fd);
}



/***************************************************************************
 * configPort()
 *   prepares serial port for communication
 * parameter:
 *   portName - string, such as "/dev/ttyAMA0"
 * returns:
 *   0 - success
 *  -1 - error
 ***************************************************************************/
int Serial::configPort(const char* portName)
{
    if( fd != -1 )
        close(fd);

    fd = open(portName, O_RDWR | O_NOCTTY | O_NDELAY);
    if( fd == -1 )
        return -1;

    fcntl(fd, F_SETFL, 0);

    // options:
    struct termios options;
    int status;

    tcgetattr(fd, &options);

    // set "raw" mode: no echo, no special control characters, no parity
    cfmakeraw(&options);

    cfsetispeed(&options, B115200);
    cfsetospeed(&options, B115200);

    options.c_cflag |= (CLOCAL | CREAD);    // Rx enable, no modem control
    options.c_cflag &= ~PARENB;    // no parity
    options.c_cflag &= ~CSTOPB;    // one stop bit
    options.c_cflag |= CS8;        // 8 data bits

    options.c_cc[VMIN]  =  0;
    options.c_cc[VTIME] = 10;    // One second general timeout (10 deciseconds)

    tcsetattr(fd, TCSANOW | TCSAFLUSH, &options);

    return 0;
}


/***************************************************************************
 * transmits data to serial port
 * returns:  0 - if all bytes have been sent out
 *          >0 - if not all bytes were sent out and retries were exhausted
 *          <0 - if error occured
 ***************************************************************************/
int Serial::transmit(unsigned char *data, int size, int ntry/*=1*/)
{
    int i, n;

    for(i=0; i<size && ntry; i+=n)
    {
        n = write(fd, data+i, size-i);
        if( n < 0 )
            return -1;
        if( n == 0 )
            ntry--;
    }
    return (size-i);
}


/***************************************************************************
 * receives data from serial port
 * returns:  0 - if all bytes have been received
 *          >0 - if not all bytes were received and retries were exhausted
 *          <0 - if error occured
 ***************************************************************************/
int Serial::receive(unsigned char *data, int size, int ntry/*=1*/)
{
    int i, n;

    for(i=0; i<size && ntry; i+=n)
    {
        n = read(fd, data+i, size-i);
        if( n < 0 )
            return -1;
        if( n == 0 )
            ntry--;
    }
    return (size-i);
}
