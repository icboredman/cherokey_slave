// Serial.h
// Serial - UART communication functionality
//
//
// rev 1.0 - 2016.07.10
//    - initial version
//
// boredman@boredomprojects.net

#include <unistd.h>  // UNIX standard function definitions
#include <fcntl.h>   // File control definitions
#include <errno.h>   // Error number definitions
#include <termios.h> // POSIX terminal control definitions

class Serial
{
private:
    // file descriptor of the serial port
    int fd;

public:
    Serial(void);
    ~Serial(void);

    int configPort(const char* portName);
    int transmit(unsigned char *data, int size, int ntry=1);
    int receive(unsigned char *data, int size, int ntry=1);
};
